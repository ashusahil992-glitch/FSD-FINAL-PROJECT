# CampusBazaar — Buy. Sell. Save. Connect.

Student marketplace and campus community platform.
**Status: Marketplace listings, paginated discovery, student accounts, owner-managed listings, buyer–seller messaging, notifications, a campus board, and protected administration are implemented.** Account registration stores a student account as pending verification; the full student ID and password hash are never returned by the authentication API.

## Stack
React + Vite + Tailwind + Redux Toolkit + Axios | Spring Boot 3 (Java 17) + JPA + Spring Security | MySQL

## Prerequisites
Java 17+, Maven 3.9+, Node 18+, and MySQL 8 running locally.

Create the database and a dedicated application user once, using a MySQL administrator account:
```sql
CREATE DATABASE campusbazaar CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci;
CREATE USER 'campusbazaar_app'@'localhost' IDENTIFIED BY 'your_strong_password';
CREATE USER 'campusbazaar_app'@'127.0.0.1' IDENTIFIED BY 'your_strong_password';
GRANT ALL PRIVILEGES ON campusbazaar.* TO 'campusbazaar_app'@'localhost';
GRANT ALL PRIVILEGES ON campusbazaar.* TO 'campusbazaar_app'@'127.0.0.1';
```
Use the same password for both accounts. The app user only needs access to the `campusbazaar` database.

## Run the backend
```bash
cd backend
# macOS/Linux
export DB_USERNAME=campusbazaar_app
export DB_PASSWORD=your_strong_password
# Windows PowerShell:
# $env:DB_USERNAME="campusbazaar_app"
# $env:DB_PASSWORD="your_strong_password"
# Generate a persistent signing secret once and keep it private:
# $env:JWT_SECRET=[Convert]::ToBase64String([Security.Cryptography.RandomNumberGenerator]::GetBytes(32))
mvn spring-boot:run
```
The database `campusbazaar` is created automatically. Check http://localhost:8080/api/health, then verify `GET /api/categories` and `GET /api/listings` return HTTP 200. The API uses the standard response envelope with records in `data`.

When `SEED_ENABLED=true`, the backend seeds fictional universities, categories, and clearly labeled demo listings only when their respective tables are empty. Demo listings are stored in the configured database and are returned by the same listing API as future listings.

## Student accounts
The frontend provides `/register` and `/login`. Registration requires a name, email, password (12–64 characters), student ID, and an active university from `GET /api/universities`. New accounts can sign in immediately but remain `PENDING_STUDENT_VERIFICATION`. The backend returns only a masked student ID.

Signed-in users can publish listings from `/sell`. Category choices come from the active database categories (`GET /api/categories`); listing creation uses authenticated `POST /api/listings` and stores the category and seller relationships in MySQL. Owners can edit their available listings with `PUT /api/listings/{id}` or remove them with `DELETE /api/listings/{id}`; removal is a soft delete that preserves the database record. The backend checks ownership on every mutation. Sale and rental listings require a positive price; exchange and giveaway records are stored at zero. Listing photo selection provides a local preview only; photo uploads are not enabled.

Marketplace search is available at `GET /api/listings/search` with optional `q`, `category`, `minPrice`, `maxPrice`, `listingType`, `sort`, `page`, and `size` parameters. `sort` accepts `newest`, `price_asc`, or `price_desc`; page numbering starts at zero and page size is limited to 50. The original `GET /api/listings` response remains available for clients that need the full available-listing collection.

Wishlist selections persist across page refreshes in the current browser using local storage. They are not synchronized to an account or across devices.

## Messages and notifications
Authenticated users can start a conversation from an available listing. Conversation messages and new-message notifications are persisted in the configured database; only the buyer and seller can view or send messages in that conversation. Use `/messages` for the inbox. The navigation notification bell shows unread message notifications and links directly to the conversation. Inbox and message updates poll periodically rather than using a persistent WebSocket connection.

## Administration
Only accounts with the backend `ADMIN` role can use `/admin` or `/api/admin/**`. Administrators can review masked student identity information, verify or suspend student accounts, reinstate suspended accounts, remove or restore listings, review user-submitted listing reports, and inspect aggregate marketplace counts. Suspended accounts are rejected on subsequent JWT-authenticated requests; reinstatement does not issue a new token. Regular student registration cannot assign the admin role. Configure the admin credentials through `ADMIN_EMAIL` and `ADMIN_PASSWORD`; the built-in demo admin credentials are for local development only.

Signed-in users can submit listing reports from the listing detail page. Reports are private to admins and are not returned by public listing APIs.

## Campus board
Open `/campus-board` while signed in to browse Lost, Found, and announcement posts for your account's university. Signed-in users can create posts, mark their own posts resolved, and remove their own posts. Board responses omit email addresses, phone numbers, and student IDs; posters should not include private contact information in post text.

Set `JWT_SECRET` in the backend environment to a private value containing at least 32 UTF-8 bytes. Keep the same value across restarts so issued tokens remain valid. If omitted, the backend logs a warning and creates a temporary random secret; tokens will be invalidated on restart. Never commit the secret or place it in frontend configuration.

## Run the frontend
```bash
cd frontend
npm install
npm run dev
```
Open http://localhost:5173.

## Tests
`cd backend && mvn test` (uses in-memory H2) · `cd frontend && npm test`

## Environment variables
See `.env.example`. Spring reads real environment variables (not `.env` files).

## Demo admin (local development only)
`admin@campusbazaar.demo` / `ChangeMe@123` (override with `ADMIN_EMAIL` / `ADMIN_PASSWORD`). Never use this in production.

## Structure
```
backend/src/main/java/com/campusbazaar/{config,controller,service,repository,entity,dto,mapper,security,exception,validation,util}
frontend/src/{components,pages,redux,services,hooks,utils,assets}
```
