package com.campusbazaar.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.Index;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import java.time.Instant;

@Entity
@Table(name = "user_notifications", indexes = @Index(name = "idx_notifications_recipient_created", columnList = "recipient_id, created_at"))
public class UserNotification extends BaseEntity {

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "recipient_id", nullable = false)
    private User recipient;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "actor_id", nullable = false)
    private User actor;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "conversation_id", nullable = false)
    private Conversation conversation;

    @Column(nullable = false, length = 300)
    private String message;

    private Instant readAt;

    protected UserNotification() {}

    public UserNotification(User recipient, User actor, Conversation conversation, String message) {
        this.recipient = recipient;
        this.actor = actor;
        this.conversation = conversation;
        this.message = message;
    }

    public User getRecipient() { return recipient; }
    public Conversation getConversation() { return conversation; }
    public String getMessage() { return message; }
    public Instant getReadAt() { return readAt; }
    public void markRead() {
        if (readAt == null) readAt = Instant.now();
    }
}
