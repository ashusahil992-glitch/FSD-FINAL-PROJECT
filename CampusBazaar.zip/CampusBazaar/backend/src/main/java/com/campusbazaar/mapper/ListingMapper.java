package com.campusbazaar.mapper;

import com.campusbazaar.dto.ListingDto;
import com.campusbazaar.entity.Listing;

public final class ListingMapper {
    private ListingMapper() {}

    public static ListingDto toDto(Listing listing) {
        return new ListingDto(
                listing.getId(),
                listing.getTitle(),
                listing.getDescription(),
                listing.getPrice(),
                listing.getCondition().name(),
                listing.getListingType().name(),
                listing.getStatus().name(),
                listing.getImageUrl(),
                new ListingDto.CategorySummary(
                        listing.getCategory().getName(),
                        listing.getCategory().getSlug(),
                        listing.getCategory().getIcon()),
                new ListingDto.SellerSummary(
                        listing.getSeller().getId(),
                        listing.getSeller().getFullName(),
                        listing.getSeller().isStudentVerified()),
                listing.isDemo(),
                listing.isPopular(),
                listing.isStudentDeal(),
                listing.isHostelClearance(),
                listing.getCreatedAt());
    }
}
