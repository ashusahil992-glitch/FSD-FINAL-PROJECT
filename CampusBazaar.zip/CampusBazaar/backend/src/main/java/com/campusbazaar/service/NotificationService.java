package com.campusbazaar.service;

import com.campusbazaar.dto.NotificationDto;
import com.campusbazaar.dto.NotificationListDto;
import com.campusbazaar.entity.User;
import com.campusbazaar.entity.UserNotification;
import com.campusbazaar.exception.ResourceNotFoundException;
import com.campusbazaar.repository.UserNotificationRepository;
import com.campusbazaar.repository.UserRepository;
import java.util.List;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class NotificationService {

    private final UserNotificationRepository notificationRepository;
    private final UserRepository userRepository;

    public NotificationService(UserNotificationRepository notificationRepository, UserRepository userRepository) {
        this.notificationRepository = notificationRepository;
        this.userRepository = userRepository;
    }

    @Transactional(readOnly = true)
    public NotificationListDto list(String email) {
        User user = findUser(email);
        List<NotificationDto> items = notificationRepository.findTop50ByRecipient_IdOrderByCreatedAtDesc(user.getId())
                .stream()
                .map(NotificationService::toDto)
                .toList();
        return new NotificationListDto(items,
                notificationRepository.countByRecipient_IdAndReadAtIsNull(user.getId()));
    }

    @Transactional
    public NotificationListDto markRead(Long id, String email) {
        User user = findUser(email);
        UserNotification notification = notificationRepository.findByIdAndRecipient_Id(id, user.getId())
                .orElseThrow(() -> new ResourceNotFoundException("Notification not found."));
        notification.markRead();
        return list(email);
    }

    @Transactional
    public NotificationListDto markAllRead(String email) {
        User user = findUser(email);
        notificationRepository.findByRecipient_IdAndReadAtIsNull(user.getId())
                .forEach(UserNotification::markRead);
        return list(email);
    }

    private User findUser(String email) {
        return userRepository.findByEmailIgnoreCase(email)
                .orElseThrow(() -> new ResourceNotFoundException("Account not found."));
    }

    private static NotificationDto toDto(UserNotification notification) {
        return new NotificationDto(
                notification.getId(),
                notification.getMessage(),
                notification.getConversation().getId(),
                notification.getConversation().getListing().getId(),
                notification.getConversation().getListing().getTitle(),
                notification.getCreatedAt(),
                notification.getReadAt());
    }
}
