package com.campusbazaar.service;

import com.campusbazaar.dto.ListingDto;
import com.campusbazaar.dto.CreateListingRequest;
import com.campusbazaar.dto.ListingSearchPageDto;
import com.campusbazaar.entity.Category;
import com.campusbazaar.entity.Listing;
import com.campusbazaar.entity.ListingCondition;
import com.campusbazaar.entity.ListingStatus;
import com.campusbazaar.entity.ListingType;
import com.campusbazaar.entity.User;
import com.campusbazaar.entity.UserStatus;
import com.campusbazaar.exception.BadRequestException;
import com.campusbazaar.exception.ResourceNotFoundException;
import com.campusbazaar.mapper.ListingMapper;
import com.campusbazaar.repository.CategoryRepository;
import com.campusbazaar.repository.ListingRepository;
import com.campusbazaar.repository.UserRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.security.access.AccessDeniedException;

import java.math.BigDecimal;
import java.util.List;
import java.util.Locale;
import java.util.ArrayList;
import jakarta.persistence.criteria.JoinType;

@Service
public class ListingService {

    private final ListingRepository listingRepository;
    private final CategoryRepository categoryRepository;
    private final UserRepository userRepository;

    public ListingService(ListingRepository listingRepository, CategoryRepository categoryRepository,
                          UserRepository userRepository) {
        this.listingRepository = listingRepository;
        this.categoryRepository = categoryRepository;
        this.userRepository = userRepository;
    }

    @Transactional(readOnly = true)
    public List<ListingDto> listAvailable() {
        return listingRepository.findByStatusOrderByCreatedAtDesc(ListingStatus.AVAILABLE)
                .stream()
                .map(ListingMapper::toDto)
                .toList();
    }

    @Transactional(readOnly = true)
    public ListingDto getAvailable(Long id) {
        return listingRepository.findByIdAndStatus(id, ListingStatus.AVAILABLE)
                .map(ListingMapper::toDto)
                .orElseThrow(() -> new ResourceNotFoundException("Listing not found."));
    }

    @Transactional(readOnly = true)
    public ListingSearchPageDto search(String query, String categorySlug, BigDecimal minPrice, BigDecimal maxPrice,
                                       ListingType listingType, String sortBy, int page, int size) {
        if (minPrice != null && maxPrice != null && minPrice.compareTo(maxPrice) > 0) {
            throw new BadRequestException("Minimum price cannot be greater than maximum price.");
        }
        Sort sort = switch (sortBy.toLowerCase(Locale.ROOT)) {
            case "newest" -> Sort.by(Sort.Direction.DESC, "createdAt");
            case "price_asc" -> Sort.by(Sort.Direction.ASC, "price").and(Sort.by(Sort.Direction.DESC, "createdAt"));
            case "price_desc" -> Sort.by(Sort.Direction.DESC, "price").and(Sort.by(Sort.Direction.DESC, "createdAt"));
            default -> throw new BadRequestException("Sort must be newest, price_asc, or price_desc.");
        };

        Specification<Listing> specification = (root, criteriaQuery, builder) -> {
            List<jakarta.persistence.criteria.Predicate> predicates = new ArrayList<>();
            predicates.add(builder.equal(root.get("status"), ListingStatus.AVAILABLE));
            if (query != null && !query.isBlank()) {
                String term = "%" + query.trim().toLowerCase(Locale.ROOT) + "%";
                var category = root.join("category", JoinType.LEFT);
                var seller = root.join("seller", JoinType.LEFT);
                predicates.add(builder.or(
                        builder.like(builder.lower(root.get("title")), term),
                        builder.like(builder.lower(root.get("description")), term),
                        builder.like(builder.lower(category.get("name")), term),
                        builder.like(builder.lower(seller.get("fullName")), term)));
            }
            if (categorySlug != null && !categorySlug.isBlank()) {
                var category = root.join("category", JoinType.LEFT);
                var parent = category.join("parent", JoinType.LEFT);
                predicates.add(builder.or(
                        builder.equal(category.get("slug"), categorySlug),
                        builder.equal(parent.get("slug"), categorySlug)));
            }
            if (minPrice != null) predicates.add(builder.greaterThanOrEqualTo(root.get("price"), minPrice));
            if (maxPrice != null) predicates.add(builder.lessThanOrEqualTo(root.get("price"), maxPrice));
            if (listingType != null) predicates.add(builder.equal(root.get("listingType"), listingType));
            criteriaQuery.distinct(true);
            return builder.and(predicates.toArray(jakarta.persistence.criteria.Predicate[]::new));
        };

        Page<Listing> results = listingRepository.findAll(specification, PageRequest.of(page, size, sort));
        return new ListingSearchPageDto(
                results.getContent().stream().map(ListingMapper::toDto).toList(),
                results.getNumber(),
                results.getSize(),
                results.getTotalElements(),
                results.getTotalPages(),
                results.isFirst(),
                results.isLast());
    }

    @Transactional
    public ListingDto create(CreateListingRequest request, String sellerEmail) {
        User seller = userRepository.findByEmailIgnoreCase(sellerEmail)
                .orElseThrow(() -> new ResourceNotFoundException("Account not found."));
        if (seller.getStatus() == UserStatus.SUSPENDED) {
            throw new BadRequestException("Suspended accounts cannot create listings.");
        }
        Category category = categoryRepository.findBySlugAndActiveTrue(request.categorySlug().trim())
                .orElseThrow(() -> new ResourceNotFoundException("The selected category is not available."));

        Listing listing = new Listing(request.title().trim(), request.description().trim(),
                normalizedPrice(request), request.condition(), request.listingType(), null, category, seller);
        return ListingMapper.toDto(listingRepository.save(listing));
    }

    @Transactional
    public ListingDto update(Long id, CreateListingRequest request, String sellerEmail) {
        Listing listing = findOwnedAvailable(id, sellerEmail);
        Category category = categoryRepository.findBySlugAndActiveTrue(request.categorySlug().trim())
                .orElseThrow(() -> new ResourceNotFoundException("The selected category is not available."));
        listing.setTitle(request.title().trim());
        listing.setDescription(request.description().trim());
        listing.setPrice(normalizedPrice(request));
        listing.setCondition(request.condition());
        listing.setListingType(request.listingType());
        listing.setCategory(category);
        return ListingMapper.toDto(listingRepository.save(listing));
    }

    @Transactional
    public void delete(Long id, String sellerEmail) {
        Listing listing = findOwnedAvailable(id, sellerEmail);
        listing.setStatus(ListingStatus.REMOVED);
        listingRepository.save(listing);
    }

    private Listing findOwnedAvailable(Long id, String sellerEmail) {
        Listing listing = listingRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Listing not found."));
        if (!listing.getSeller().getEmail().equalsIgnoreCase(sellerEmail)) {
            throw new AccessDeniedException("You can only manage your own listings.");
        }
        if (listing.isDemo()) {
            throw new AccessDeniedException("Demo listings cannot be changed.");
        }
        if (listing.getStatus() != ListingStatus.AVAILABLE) {
            throw new BadRequestException("Only available listings can be changed.");
        }
        return listing;
    }

    private BigDecimal normalizedPrice(CreateListingRequest request) {
        BigDecimal price = request.price();
        if (request.listingType() == ListingType.GIVEAWAY || request.listingType() == ListingType.EXCHANGE) {
            return BigDecimal.ZERO;
        }
        if (price == null || price.compareTo(BigDecimal.ZERO) <= 0) {
            throw new BadRequestException("A price greater than zero is required for sale and rental listings.");
        }
        return price;
    }
}
